<?php
/**
 * Plugin Name: MusicFetcher
 * Description: Questo plugin ti permette di spawnare i primi 3 link spotify nel db
 * Version: 1.0
 * Author: Gerardo Ruben Paparella
 **/

// Includi il file del plugin
include_once( 'fetch_music.php' );